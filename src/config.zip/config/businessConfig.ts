import type { BusinessConfig } from './businessConfig.types.ts'

export const businessConfig: BusinessConfig = {
  identity: {
    name: 'Barber Kings',
    tagline: 'Klassische Schnitte. Moderner Stil.',
    industry: 'barbershop',
    logo: {
      src: '/favicon.svg',
      alt: 'Barber Kings Logo',
      width: 48,
    },
  },

  theme: {
    colors: {
      primary: '#1a1a1a',
      primaryHover: '#333333',
      secondary: '#c9a227',
      background: '#faf9f7',
      surface: '#ffffff',
      text: '#4a4a4a',
      textHeading: '#1a1a1a',
      border: '#e5e4e0',
    },
  },

  contact: {
    phone: '+49 30 12345678',
    email: 'kontakt@barberkings.de',
    address: {
      street: 'Musterstraße 12',
      zip: '10115',
      city: 'Berlin',
      country: 'Deutschland',
    },
    social: {
      instagram: 'https://instagram.com/barberkings',
    },
  },

  whatsapp: {
    enabled: true,
    phone: '493012345678',
    defaultMessage: 'Hallo, ich möchte einen Termin vereinbaren.',
  },

  maps: {
    enabled: true,
    embedUrl:
      'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2427.409!2d13.388!3d52.532!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1',
    linkUrl: 'https://maps.google.com/?q=Musterstraße+12+10115+Berlin',
  },

  navigation: [
    { id: 'services', label: 'Leistungen', href: '#services' },
    { id: 'reviews', label: 'Bewertungen', href: '#reviews' },
    { id: 'faq', label: 'FAQ', href: '#faq' },
    { id: 'contact', label: 'Kontakt', href: '#contact' },
  ],

  hero: {
    headline: 'Dein Barbershop in Berlin',
    subline: 'Präzise Schnitte, Bartpflege und entspannte Atmosphäre – ohne Terminstress.',
    ctaPrimary: {
      label: 'Termin per WhatsApp',
      href: '#contact',
      type: 'whatsapp',
    },
    ctaSecondary: {
      label: 'Anrufen',
      href: 'tel:+493012345678',
      type: 'phone',
    },
  },

  services: [
    {
      id: 'haircut',
      title: 'Herrenschnitt',
      description: 'Klassischer oder moderner Schnitt inkl. Waschen und Styling.',
      icon: '✂️',
      price: 'ab 28 €',
    },
    {
      id: 'beard',
      title: 'Bartpflege',
      description: 'Trimmen, Konturieren und Pflege mit Premium-Produkten.',
      icon: '🪒',
      price: 'ab 18 €',
    },
    {
      id: 'combo',
      title: 'Hair & Beard Combo',
      description: 'Komplettpaket für einen durchgestylten Look.',
      icon: '💈',
      price: 'ab 42 €',
    },
    {
      id: 'kids',
      title: 'Kinderhaarschnitt',
      description: 'Geduldig und kindgerecht – für die kleinen Könige.',
      icon: '👦',
      price: 'ab 20 €',
    },
  ],

  about: {
    title: 'Über uns',
    text: 'Seit 2018 verbinden wir traditionelles Handwerk mit modernem Stil. Unser Team aus erfahrenen Barbiers sorgt dafür, dass du dich wohlfühlst und top gestylt rausgehst.',
  },

  reviews: [
    {
      id: 'review-1',
      author: 'Max S.',
      rating: 5,
      text: 'Bester Barbershop in der Gegend. Immer sauber, freundlich und präzise.',
      date: '2025-11-12',
      source: 'Google',
    },
    {
      id: 'review-2',
      author: 'Jonas K.',
      rating: 5,
      text: 'Mega Bartpflege und entspannte Stimmung. Komme seit Jahren.',
      date: '2025-10-03',
      source: 'Google',
    },
    {
      id: 'review-3',
      author: 'Tim R.',
      rating: 4,
      text: 'Gute Schnitte, faire Preise. Samstags etwas voll – lohnt sich trotzdem.',
      date: '2025-09-18',
      source: 'Google',
    },
  ],

  faq: [
    {
      id: 'faq-1',
      question: 'Brauche ich einen Termin?',
      answer:
        'Walk-ins sind willkommen, aber mit Termin hast du garantiert kein Warten. Schreib uns einfach per WhatsApp.',
    },
    {
      id: 'faq-2',
      question: 'Welche Zahlungsmethoden akzeptiert ihr?',
      answer: 'Bar, EC-Karte und kontaktlose Zahlung.',
    },
    {
      id: 'faq-3',
      question: 'Gibt es Parkplätze in der Nähe?',
      answer: 'Ja, öffentliche Parkplätze findest du direkt in der Seitenstraße.',
    },
  ],

  openingHours: {
    schedule: {
      monday: { open: '10:00', close: '19:00' },
      tuesday: { open: '10:00', close: '19:00' },
      wednesday: { open: '10:00', close: '19:00' },
      thursday: { open: '10:00', close: '20:00' },
      friday: { open: '10:00', close: '20:00' },
      saturday: { open: '09:00', close: '16:00' },
      sunday: null,
    },
    note: 'Feiertage können abweichen – kurz anrufen oder per WhatsApp nachfragen.',
  },

  seo: {
    title: 'Barber Kings – Barbershop in Berlin',
    description:
      'Herrenschnitt, Bartpflege und Styling in Berlin-Mitte. Termine per WhatsApp oder Walk-in.',
    keywords: ['barbershop', 'berlin', 'herrenschnitt', 'bartpflege'],
  },

  sections: {
    hero: true,
    services: true,
    about: true,
    reviews: true,
    faq: true,
    openingHours: true,
    contact: true,
    map: true,
  },
}
