import { useBusinessConfig } from '../../hooks/useBusinessConfig.tsx'
import { Container } from './Container.tsx'
import './layout.css'

function buildWhatsAppUrl(phone: string, message: string): string {
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`
}

export function Header() {
  const { identity, navigation, whatsapp, contact, hero } = useBusinessConfig()

  const cta = whatsapp.enabled
    ? {
        href: buildWhatsAppUrl(whatsapp.phone, whatsapp.defaultMessage),
        label: hero.ctaPrimary.type === 'whatsapp' ? hero.ctaPrimary.label : 'WhatsApp',
      }
    : {
        href: `tel:${contact.phone.replace(/\s/g, '')}`,
        label: 'Anrufen',
      }

  return (
    <header className="header">
      <Container>
        <div className="header__inner">
          <div className="header__top">
            <a href="#" className="header__brand">
              {identity.name}
            </a>
            <a
              href={cta.href}
              className="header__cta"
              target={whatsapp.enabled ? '_blank' : undefined}
              rel={whatsapp.enabled ? 'noopener noreferrer' : undefined}
            >
              {cta.label}
            </a>
          </div>
          <nav className="header__nav" aria-label="Hauptnavigation">
            {navigation.map((item) => (
              <a key={item.id} href={item.href} className="header__nav-link">
                {item.label}
              </a>
            ))}
          </nav>
        </div>
      </Container>
    </header>
  )
}
