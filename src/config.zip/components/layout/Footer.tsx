import { useBusinessConfig } from '../../hooks/useBusinessConfig.tsx'
import type { Weekday } from '../../config/businessConfig.types.ts'
import { Container } from './Container.tsx'
import './layout.css'

const WEEKDAY_LABELS: Record<Weekday, string> = {
  monday: 'Mo',
  tuesday: 'Di',
  wednesday: 'Mi',
  thursday: 'Do',
  friday: 'Fr',
  saturday: 'Sa',
  sunday: 'So',
}

const WEEKDAY_ORDER: Weekday[] = [
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday',
  'sunday',
]

export function Footer() {
  const { identity, contact, openingHours } = useBusinessConfig()
  const { address } = contact
  const year = new Date().getFullYear()

  return (
    <footer className="footer">
      <Container>
        <div className="footer__grid">
          <div>
            <h2 className="footer__title">Kontakt</h2>
            <p className="footer__text">
              <a href={`tel:${contact.phone.replace(/\s/g, '')}`}>{contact.phone}</a>
              <br />
              <a href={`mailto:${contact.email}`}>{contact.email}</a>
              <br />
              {address.street}
              <br />
              {address.zip} {address.city}
            </p>
          </div>

          <div>
            <h2 className="footer__title">Öffnungszeiten</h2>
            <div>
              {WEEKDAY_ORDER.map((day) => {
                const schedule = openingHours.schedule[day]
                return (
                  <div key={day} className="footer__hours-row">
                    <span>{WEEKDAY_LABELS[day]}</span>
                    <span>
                      {schedule ? `${schedule.open} – ${schedule.close}` : 'Geschlossen'}
                    </span>
                  </div>
                )
              })}
            </div>
            {openingHours.note && (
              <p className="footer__text footer__note">{openingHours.note}</p>
            )}
          </div>

          <div>
            <h2 className="footer__title">Rechtliches</h2>
            <p className="footer__text">
              {identity.name}
              <br />
              {address.street}, {address.zip} {address.city}
              <br />
              {address.country}
              <br />
              <a href={`mailto:${contact.email}`}>{contact.email}</a>
            </p>
          </div>
        </div>

        <div className="footer__legal">
          <p className="footer__text">
            © {year} {identity.name}. Alle Rechte vorbehalten.
          </p>
        </div>
      </Container>
    </footer>
  )
}
