import type { ContactConfig, CtaConfig, WhatsAppConfig } from '../../config/businessConfig.types.ts'
import { useBusinessConfig } from '../../hooks/useBusinessConfig.tsx'
import { Container } from '../layout/Container.tsx'
import { Section } from '../layout/Section.tsx'
import './sections.css'

function buildWhatsAppUrl(phone: string, message: string): string {
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`
}

function resolveCtaHref(
  cta: CtaConfig,
  whatsapp: WhatsAppConfig,
  contact: ContactConfig,
): string {
  switch (cta.type) {
    case 'whatsapp':
      return whatsapp.enabled
        ? buildWhatsAppUrl(whatsapp.phone, whatsapp.defaultMessage)
        : `tel:${contact.phone.replace(/\s/g, '')}`
    case 'phone':
      return `tel:${contact.phone.replace(/\s/g, '')}`
    case 'link':
      return cta.href
  }
}

function isExternalCta(cta: CtaConfig, whatsapp: WhatsAppConfig): boolean {
  if (cta.type === 'whatsapp' && whatsapp.enabled) return true
  if (cta.type === 'link') return cta.href.startsWith('http')
  return false
}

export function HeroSection() {
  const { identity, hero, contact, whatsapp } = useBusinessConfig()

  return (
    <Section id="hero" className="hero">
      <Container>
        <div className="hero__grid">
          <div className="hero__content">
            <span className="hero__eyebrow">{identity.tagline}</span>
            <h1 className="hero__headline">{hero.headline}</h1>
            <p className="hero__subline">{hero.subline}</p>
            <div className="hero__actions">
              <a
                href={resolveCtaHref(hero.ctaPrimary, whatsapp, contact)}
                className="hero__cta hero__cta--primary"
                target={isExternalCta(hero.ctaPrimary, whatsapp) ? '_blank' : undefined}
                rel={isExternalCta(hero.ctaPrimary, whatsapp) ? 'noopener noreferrer' : undefined}
              >
                {hero.ctaPrimary.label}
              </a>
              {hero.ctaSecondary && (
                <a
                  href={resolveCtaHref(hero.ctaSecondary, whatsapp, contact)}
                  className="hero__cta hero__cta--secondary"
                  target={
                    isExternalCta(hero.ctaSecondary, whatsapp) ? '_blank' : undefined
                  }
                  rel={
                    isExternalCta(hero.ctaSecondary, whatsapp) ? 'noopener noreferrer' : undefined
                  }
                >
                  {hero.ctaSecondary.label}
                </a>
              )}
            </div>
          </div>

          {hero.image && (
            <div className="hero__media">
              <img
                src={hero.image}
                alt={hero.headline}
                className="hero__image"
                loading="eager"
              />
            </div>
          )}
        </div>
      </Container>
    </Section>
  )
}
