import { useBusinessConfig } from '../../hooks/useBusinessConfig.tsx'
import { Container } from '../layout/Container.tsx'
import { Section } from '../layout/Section.tsx'
import './sections.css'

export function ServicesSection() {
  const { services } = useBusinessConfig()

  if (services.length === 0) {
    return null
  }

  return (
    <Section id="services" className="services">
      <Container>
        <ul className="services__grid">
          {services.map((service) => (
            <li key={service.id} className="services__card">
              {service.icon && (
                <span className="services__icon" aria-hidden="true">
                  {service.icon}
                </span>
              )}
              <h2 className="services__title">{service.title}</h2>
              <p className="services__description">{service.description}</p>
              {service.price && <p className="services__price">{service.price}</p>}
            </li>
          ))}
        </ul>
      </Container>
    </Section>
  )
}
