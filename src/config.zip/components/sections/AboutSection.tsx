import { useBusinessConfig } from '../../hooks/useBusinessConfig.tsx'
import { Container } from '../layout/Container.tsx'
import { Section } from '../layout/Section.tsx'
import './sections.css'

export function AboutSection() {
  const { about } = useBusinessConfig()

  if (!about) {
    return null
  }

  return (
    <Section id="about" className="about">
      <Container>
        <div className="about__content">
          <h2 className="about__title">{about.title}</h2>
          <p className="about__text">{about.text}</p>
        </div>
      </Container>
    </Section>
  )
}
