import { useBusinessConfig } from '../../hooks/useBusinessConfig.tsx'
import { Container } from '../layout/Container.tsx'
import { Section } from '../layout/Section.tsx'
import './sections.css'

export function FaqSection() {
  const { faq } = useBusinessConfig()

  if (faq.length === 0) {
    return null
  }

  return (
    <Section id="faq" className="faq">
      <Container>
        <div className="faq__list">
          {faq.map((item) => (
            <details key={item.id} className="faq__item">
              <summary className="faq__question">{item.question}</summary>
              <p className="faq__answer">{item.answer}</p>
            </details>
          ))}
        </div>
      </Container>
    </Section>
  )
}
