import type { Weekday } from '../../config/businessConfig.types.ts'
import { useBusinessConfig } from '../../hooks/useBusinessConfig.tsx'
import { Container } from '../layout/Container.tsx'
import { Section } from '../layout/Section.tsx'
import './sections.css'

const WEEKDAY_LABELS: Record<Weekday, string> = {
  monday: 'Mo',
  tuesday: 'Di',
  wednesday: 'Mi',
  thursday: 'Do',
  friday: 'Fr',
  saturday: 'Sa',
  sunday: 'So',
}

const WEEKDAY_ORDER: Weekday[] = [
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday',
  'sunday',
]

const CLOSED_LABEL = '—'

export function OpeningHoursSection() {
  const { openingHours } = useBusinessConfig()

  if (!openingHours) {
    return null
  }

  return (
    <Section id="opening-hours" className="opening-hours">
      <Container>
        <dl className="opening-hours__list">
          {WEEKDAY_ORDER.map((day) => {
            const schedule = openingHours.schedule[day]

            return (
              <div key={day} className="opening-hours__row">
                <dt className="opening-hours__day">{WEEKDAY_LABELS[day]}</dt>
                <dd className="opening-hours__time">
                  {schedule ? `${schedule.open} – ${schedule.close}` : CLOSED_LABEL}
                </dd>
              </div>
            )
          })}
        </dl>
        {openingHours.note && <p className="opening-hours__note">{openingHours.note}</p>}
      </Container>
    </Section>
  )
}
