import { useBusinessConfig } from '../../hooks/useBusinessConfig.tsx'
import { Container } from '../layout/Container.tsx'
import { Section } from '../layout/Section.tsx'
import './sections.css'

export function MapSection() {
  const { maps } = useBusinessConfig()

  if (!maps.enabled || !maps.embedUrl) {
    return null
  }

  return (
    <Section id="map" className="map">
      <Container>
        <div className="map__embed">
          <iframe
            src={maps.embedUrl}
            className="map__iframe"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title={maps.linkUrl ?? maps.embedUrl}
          />
        </div>
      </Container>
    </Section>
  )
}
