import { useBusinessConfig } from '../../hooks/useBusinessConfig.tsx'
import { Container } from '../layout/Container.tsx'
import { Section } from '../layout/Section.tsx'
import './sections.css'

function buildWhatsAppUrl(phone: string, message: string): string {
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`
}

export function ContactSection() {
  const { contact, whatsapp } = useBusinessConfig()
  const { address } = contact
  const phoneHref = `tel:${contact.phone.replace(/\s/g, '')}`

  return (
    <Section id="contact" className="contact">
      <Container>
        <div className="contact__grid">
          <div className="contact__details">
            <p className="contact__item">
              <a href={phoneHref} className="contact__link">
                {contact.phone}
              </a>
            </p>
            <p className="contact__item">
              <a href={`mailto:${contact.email}`} className="contact__link">
                {contact.email}
              </a>
            </p>
            <address className="contact__address">
              {address.street}
              <br />
              {address.zip} {address.city}
              <br />
              {address.country}
            </address>
          </div>

          {whatsapp.enabled && (
            <a
              href={buildWhatsAppUrl(whatsapp.phone, whatsapp.defaultMessage)}
              className="contact__whatsapp"
              target="_blank"
              rel="noopener noreferrer"
            >
              {whatsapp.defaultMessage}
            </a>
          )}
        </div>
      </Container>
    </Section>
  )
}
